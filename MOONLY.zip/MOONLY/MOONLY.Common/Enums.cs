using System;
using System.Collections.Generic;
using System.Text;

namespace MOONLY.Common
{
   public class Enums
    {
       public enum KieuNguoiDung
       {
           CUSTOMER = 1,
           ADMINISTRATOR = 2
       }
    }
}
