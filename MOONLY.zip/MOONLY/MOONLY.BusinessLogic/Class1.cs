using System;
using System.Collections.Generic;
using System.Text;

namespace MOONLY.BusinessLogic
{
    public class Class1
    {
    }
}
