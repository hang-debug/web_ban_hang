using System;
using System.Collections.Generic;
using System.Text;

namespace MOONLY.DataAccess
{
    public class Class1
    {
    }
}
